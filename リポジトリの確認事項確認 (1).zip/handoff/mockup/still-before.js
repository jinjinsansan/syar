/**
 * ★比較用：**現行** apps/web/src/app/still/page.tsx の描き方をそのまま再現します。
 *   16進も分岐もあちらのファイルのままです。**確認ページの「前」だけに使います。**
 *   ⚠️ ここには非整数倍の縮小が入ります（それが「前」の問題そのものなので、直しません）。
 */
(function (g) {
  'use strict';
  function hex2rgb(h) { var v = parseInt(h.slice(1), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; }

  /** 勝負服だけ塗った帯（毛色なし・逆光なし＝現行と同じ状態） */
  function buildPlainAtlas(sheet, pal, gates) {
    var out = {};
    gates.forEach(function (gate) {
      var c = document.createElement('canvas');
      c.width = 1320; c.height = 140;
      var x = c.getContext('2d');
      x.imageSmoothingEnabled = false;
      x.drawImage(sheet, 0, 0);
      var im = x.getImageData(0, 0, 1320, 140), d = im.data;
      var silk = hex2rgb(pal['silk-' + gate] || '#cccccc');
      for (var i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) { d[i + 3] = 0; continue; }
        var r = d[i], gg = d[i + 1], b = d[i + 2];
        var mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), dl = mx - mn;
        if (mx === 0 || dl / mx < 0.35) continue;
        var h;
        if (mx === r) h = ((gg - b) / dl) % 6; else if (mx === gg) h = (b - r) / dl + 2; else h = (r - gg) / dl + 4;
        h *= 60; if (h < 0) h += 360;
        if (h >= 200 && h <= 260) {
          var v = mx / 255;
          d[i] = silk[0] * v; d[i + 1] = silk[1] * v; d[i + 2] = silk[2] * v;
        }
      }
      x.putImageData(im, 0, 0);
      out[gate] = c;
    });
    return out;
  }

  function drawBefore(ctx, atlas, pal) {
    var W = 1280, H = 720, horizon = 0.30, horseScale = 1.55, packTight = 0.62;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, W, H);
    var hy = Math.round(H * horizon);
    ctx.fillStyle = '#93bad0'; ctx.fillRect(0, 0, W, hy);
    ctx.fillStyle = 'rgba(255,255,255,0.10)';
    [[0.35, 0.42], [0.55, 0.60]].forEach(function (b) {
      ctx.fillRect(0, Math.round(hy * b[0]), W, Math.round(hy * (b[1] - b[0])));
    });
    var sTop = hy, sH = Math.round(H * 0.085);
    ctx.fillStyle = '#5b6068'; ctx.fillRect(0, sTop, W, sH);
    for (var y = sTop + 3; y < sTop + sH - 2; y += 4) {
      for (var x = 2; x < W; x += 5) {
        ctx.fillStyle = ((x * 3 + y * 7) % 11 < 5) ? 'rgba(255,255,255,0.22)' : 'rgba(0,0,0,0.22)';
        ctx.fillRect(x, y, 2, 2);
      }
    }
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.fillRect(0, sTop, W, 5);
    var y0 = hy + sH;
    [[0, 0.055, '#24401f'], [0.055, 0.05, '#2f5228']].forEach(function (t) {
      var top = y0 + Math.round(H * t[0]), hh = Math.round(H * t[1]);
      ctx.fillStyle = t[2]; ctx.fillRect(0, top, W, hh);
      for (var yy = top + 2; yy < top + hh - 1; yy += 3) {
        for (var xx = 1; xx < W; xx += 4) {
          ctx.fillStyle = ((xx * 5 + yy * 3) % 13 < 6) ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.14)';
          ctx.fillRect(xx, yy, 3, 2);
        }
      }
    });
    var trackTop = hy + sH + Math.round(H * 0.105);
    ctx.fillStyle = '#2b2f28'; ctx.fillRect(0, trackTop - 10, W, 10);
    ctx.fillStyle = 'rgba(240,240,235,0.55)';
    for (var fx = 0; fx < W; fx += 44) ctx.fillRect(fx, trackTop - 10, 3, 10);
    ctx.fillStyle = '#4c7d41'; ctx.fillRect(0, trackTop, W, H - trackTop);
    var by = trackTop, band = 14, dark = false;
    while (by < H) {
      ctx.fillStyle = dark ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.05)';
      ctx.fillRect(0, by, W, band);
      by += band; band = Math.round(band * 1.16); dark = !dark;
    }
    var gx = Math.round(W * 0.80);
    for (var i = 0; i * 22 < H - trackTop; i += 1) {
      ctx.fillStyle = i % 2 === 0 ? '#f2efe4' : '#22201c';
      ctx.fillRect(gx, trackTop + i * 22, 7, 22);
    }
    ctx.fillStyle = '#f2efe4'; ctx.fillRect(gx - 30, trackTop - 46, 70, 34);
    ctx.fillStyle = '#22201c'; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('GOAL', gx + 5, trackTop - 22); ctx.textAlign = 'left';

    var rows = [0.30, 0.50, 0.70, 0.90], placed = [], gate = 1;
    for (var r = 0; r < rows.length; r += 1) {
      for (var n = 0; n < 3; n += 1) {
        var depth = rows[r];
        placed.push({
          gate: gate,
          x: W * (0.10 + n * 0.30 * packTight + r * 0.085) - (r % 2) * 40,
          y: trackTop + (H - trackTop) * (0.10 + depth * 0.62),
          k: horseScale * (0.62 + depth * 0.55)
        });
        gate = gate >= 12 ? 1 : gate + 1;
      }
    }
    placed.sort(function (a, b) { return a.y - b.y; });
    placed.forEach(function (p) {
      var img = atlas[p.gate];
      if (!img) return;
      var w = 220 * p.k, h = 140 * p.k;
      ctx.globalAlpha = 0.22; ctx.fillStyle = '#22381c';
      ctx.beginPath(); ctx.ellipse(p.x - w * 0.02, p.y - 2, w * 0.07, w * 0.018, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#c9d2b4';
      for (var d2 = 0; d2 < 3; d2 += 1) {
        ctx.globalAlpha = 0.10 - d2 * 0.028;
        ctx.beginPath();
        ctx.ellipse(p.x - w * (0.16 + d2 * 0.07), p.y - 2, w * (0.055 - d2 * 0.012), w * 0.012, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.drawImage(img, ((p.gate * 2) % 6) * 220, 0, 220, 140, p.x - w / 2, p.y - h * 0.92, w, h);
    });

    var ry = Math.round(H * 0.845);
    for (var rx = -30; rx < W; rx += 168) {
      ctx.fillStyle = '#d9d6c9'; ctx.fillRect(rx, ry, 5, 54);
      ctx.fillStyle = 'rgba(0,0,0,0.20)'; ctx.fillRect(rx + 4, ry, 2, 54);
    }
    [[0, 8], [26, 6]].forEach(function (b) {
      ctx.fillStyle = '#efece0'; ctx.fillRect(0, ry + b[0], W, b[1]);
      ctx.fillStyle = 'rgba(0,0,0,0.16)'; ctx.fillRect(0, ry + b[0] + b[1], W, 2);
    });

    var ord = [12, 9, 7, 3, 11, 1, 5, 8, 10, 2, 4, 6], size = 30, gap = 10;
    var wBar = ord.length * (size + gap) + 24, rr = size / 2;
    ctx.fillStyle = 'rgba(22,20,17,0.55)';
    ctx.fillRect(Math.round((W - wBar) / 2), 12, wBar, size + 20);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (var oi = 0; oi < ord.length; oi += 1) {
      var col = hex2rgb(pal['silk-' + ord[oi]] || '#cccccc');
      var ccx = Math.round((W - wBar) / 2) + 12 + rr + oi * (rr * 2 + gap), ccy = 22 + rr;
      if (oi === 0) { ctx.beginPath(); ctx.arc(ccx, ccy, rr + 3, 0, Math.PI * 2); ctx.fillStyle = '#f2c14e'; ctx.fill(); }
      ctx.beginPath(); ctx.arc(ccx, ccy, rr, 0, Math.PI * 2);
      ctx.fillStyle = 'rgb(' + col[0] + ',' + col[1] + ',' + col[2] + ')'; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(20,20,18,0.6)'; ctx.stroke();
      ctx.fillStyle = (col[0] * 299 + col[1] * 587 + col[2] * 114) / 1000 < 140 ? '#f5f5f5' : '#141414';
      ctx.font = 'bold ' + Math.round(rr * 1.15) + 'px sans-serif';
      ctx.fillText(String(ord[oi]), ccx, ccy + 1);
    }
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';

    var cy2 = Math.round(H * 0.90);
    ctx.fillStyle = '#efe9dc'; ctx.fillRect(0, cy2, W, H - cy2);
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(0, cy2, W, 3);
    ctx.fillStyle = '#22201c'; ctx.font = 'bold 30px sans-serif';
    ctx.fillText('さあ直線　7番が内から抜け出した', 34, cy2 + 48);
  }

  g.STARBefore = { buildPlainAtlas: buildPlainAtlas, drawBefore: drawBefore };
})(typeof window !== 'undefined' ? window : globalThis);
